"""Standalone runtime service launcher.

The launcher resolves its installed root from the file location of this
module. The forbidden source-repo and sibling-repo env names live once in
``_forbidden_tokens.py``; the runtime never reads them. The launcher
exposes the auth/health/action/lifecycle contracts on a local FastAPI
socket. Phases covered:

- Launch + readiness + setup-status + auth-status + action list (P4).
- Read-only Graph action surface (P5).
- UCP contract layer (P6).
- Full auth lifecycle (start/check) and token-store-backed readiness (fix R3).
"""

from __future__ import annotations

import os
import sys
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from . import RUNTIME_VERSION
from .audit import build_envelope
from .auth.token_store import TokenStore, TokenStoreError
from .graph.registry import READ_ONLY_REGISTRY
from .setup import SetupConfig, SetupConfigError, load_setup_from_env

# Submodules that transitively import third-party deps (httpx, fastapi,
# uvicorn) are NOT imported at module load. They are imported lazily inside
# the functions that use them - either inside `build_app`, which is only
# reached after `plan_launch` confirms the dependency probe is clean, or
# inside the run() helper which is only invoked by the CLI entry point.
# This guarantees `import m365_runtime.launcher` succeeds even when httpx
# / fastapi / uvicorn are absent, so `plan_launch()` can return a
# structured `outcome=dependency_missing` instead of crashing at import.


LAUNCH_OUTCOMES = (
    "started",
    "port_conflict",
    "config_invalid",
    "dependency_missing",
    "launch_unknown",
)
TOKEN_ACCOUNT_ACCESS = "access_token"
TOKEN_ACCOUNT_REFRESH = "refresh_token"
TOKEN_ACCOUNT_EXPIRES_AT = "token_expires_at"
# plan:m365-cps-trkB-p6-auth-mode-tiers:T3 / L113.L_TOKEN_STORE_PERSISTS_TIER
TOKEN_ACCOUNT_SESSION_TIER = "session_tier"
DEFAULT_SESSION_TIER = "read-only"
TOKEN_REFRESH_MARGIN_SECONDS = 300
DELEGATED_AUTH_MODES = frozenset({"auth_code_pkce", "device_code"})

RUNTIME_REQUIRED_MODULES = ("httpx", "fastapi", "uvicorn")
RUNTIME_CONDITIONAL_MODULES = {
    "app_only_certificate": ("jwt",),
}


def _probe_required_dependencies(*, auth_mode: str | None = None) -> tuple[list[str], list[str]]:
    """Return (present, missing) for the modules this runtime needs at launch.

    Always probes the unconditionally-required runtime modules. If
    ``auth_mode`` is provided, also probes the auth-mode conditional set.
    """
    import importlib

    present: list[str] = []
    missing: list[str] = []
    targets: list[str] = list(RUNTIME_REQUIRED_MODULES)
    if auth_mode and auth_mode in RUNTIME_CONDITIONAL_MODULES:
        targets.extend(RUNTIME_CONDITIONAL_MODULES[auth_mode])
    for name in targets:
        try:
            importlib.import_module(name)
            present.append(name)
        except ImportError:
            missing.append(name)
    return present, missing


class LaunchError(RuntimeError):
    def __init__(self, outcome: str, message: str) -> None:
        super().__init__(f"LaunchError {outcome}: {message}")
        self.outcome = outcome
        self.message = message


@dataclass
class LaunchPlan:
    outcome: str
    installed_root: Path
    setup: SetupConfig | None
    listen_host: str
    listen_port: int
    detail: dict[str, Any]


def installed_root_from_module() -> Path:
    return Path(__file__).resolve().parent.parent


def plan_launch(
    *, host: str | None = None, port: int | None = None, env: dict[str, str] | None = None
) -> LaunchPlan:
    started_at = time.monotonic()
    try:
        installed_root = installed_root_from_module()
    except Exception as exc:
        return LaunchPlan(
            outcome="dependency_missing",
            installed_root=Path("."),
            setup=None,
            listen_host=host or "127.0.0.1",
            listen_port=port or 9300,
            detail={"reason": "installed_root_unresolved", "exception": str(exc)},
        )
    if not installed_root.is_dir():
        return LaunchPlan(
            outcome="dependency_missing",
            installed_root=installed_root,
            setup=None,
            listen_host=host or "127.0.0.1",
            listen_port=port or 9300,
            detail={"reason": "installed_root_not_dir"},
        )
    present, missing = _probe_required_dependencies()
    if missing:
        return LaunchPlan(
            outcome="dependency_missing",
            installed_root=installed_root,
            setup=None,
            listen_host=host or "127.0.0.1",
            listen_port=port or 9300,
            detail={
                "reason": "required_modules_missing",
                "missing_modules": missing,
                "present_modules": present,
                "remediation": "install the missing modules in the pack runtime environment",
            },
        )
    listen_host = host if host is not None else (os.getenv("M365_RUNTIME_HOST") or "127.0.0.1")
    try:
        port_value: int | str = (
            port if port is not None else (os.getenv("M365_RUNTIME_PORT") or "9300")
        )
        listen_port = int(port_value)
    except ValueError:
        return LaunchPlan(
            outcome="config_invalid",
            installed_root=installed_root,
            setup=None,
            listen_host=listen_host,
            listen_port=0,
            detail={"reason": "invalid_port"},
        )
    setup_obj: SetupConfig | None = None
    setup_detail: dict[str, Any] = {"loaded": False}
    if env is not None:
        try:
            setup_obj = load_setup_from_env_dict(env)
            setup_detail = {"loaded": True, "auth_mode": setup_obj.auth_mode}
        except SetupConfigError as exc:
            setup_detail = {"loaded": False, "reason": str(exc)}
    else:
        try:
            setup_obj = load_setup_from_env()
            setup_detail = {"loaded": True, "auth_mode": setup_obj.auth_mode}
        except SetupConfigError as exc:
            setup_detail = {"loaded": False, "reason": str(exc)}
    elapsed = time.monotonic() - started_at
    if elapsed > 5.0:
        return LaunchPlan(
            outcome="launch_unknown",
            installed_root=installed_root,
            setup=setup_obj,
            listen_host=listen_host,
            listen_port=listen_port,
            detail={"reason": "exceeded_5s_budget", "elapsed_s": round(elapsed, 3)},
        )
    return LaunchPlan(
        outcome="started",
        installed_root=installed_root,
        setup=setup_obj,
        listen_host=listen_host,
        listen_port=listen_port,
        detail={"setup": setup_detail, "elapsed_s": round(elapsed, 3)},
    )


def load_setup_from_env_dict(env: dict[str, str]) -> SetupConfig:
    saved = dict(os.environ)
    try:
        os.environ.clear()
        os.environ.update(env)
        return load_setup_from_env()
    finally:
        os.environ.clear()
        os.environ.update(saved)


def _make_token_store(plan: LaunchPlan) -> TokenStore | None:
    if plan.setup is None:
        return None
    try:
        return TokenStore.from_setup(plan.setup, plan.installed_root)
    except TokenStoreError:
        return None


def _store_access_token(
    store: TokenStore | None,
    access_token: str | None,
    refresh_token: str | None = None,
    expires_at: int | None = None,
) -> bool:
    if store is None or not access_token:
        return False
    try:
        store.put(TOKEN_ACCOUNT_ACCESS, access_token)
        if refresh_token:
            store.put(TOKEN_ACCOUNT_REFRESH, refresh_token)
        if expires_at:
            store.put(TOKEN_ACCOUNT_EXPIRES_AT, str(int(expires_at)))
        return True
    except Exception:
        return False


def _clear_stored_tokens(store: TokenStore | None) -> None:
    if store is None:
        return
    for account in (TOKEN_ACCOUNT_ACCESS, TOKEN_ACCOUNT_REFRESH, TOKEN_ACCOUNT_EXPIRES_AT):
        try:
            store.clear(account)
        except Exception:
            continue


def _store_get(store: TokenStore | None, account: str) -> str | None:
    if store is None:
        return None
    try:
        value = store.get(account)
    except Exception:
        return None
    if value is None:
        return None
    value = str(value).strip()
    return value or None


def _coerce_expires_at(raw: Any) -> int | None:
    if raw in (None, ""):
        return None
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return None
    return value if value > 0 else None


def _token_is_fresh(expires_at: int | None, *, now: int | None = None) -> bool:
    if expires_at is None:
        return False
    now_value = int(time.time()) if now is None else now
    return expires_at - now_value > TOKEN_REFRESH_MARGIN_SECONDS


def _delegated_refresh_supported(setup: SetupConfig | None) -> bool:
    return setup is not None and setup.auth_mode in DELEGATED_AUTH_MODES


def _looked_up_secret_or_cert_ref(
    setup: SetupConfig, store: TokenStore | None, ref_kind: str
) -> str | None:
    """Resolve a configured secret/cert reference into raw material at request time.

    Production deployments place the secret value (or PEM private key) in the
    keychain item named by the ref. The runtime never holds these values
    statically and never logs them.
    """
    if store is None:
        return None
    if ref_kind == "secret":
        ref = (setup.app_only_secret_ref or "").strip()
    elif ref_kind == "certificate":
        ref = (setup.app_only_certificate_ref or "").strip()
    else:
        return None
    if not ref:
        return None
    try:
        return store.get(ref)
    except Exception:
        return None


def build_app(
    plan: LaunchPlan, *, oauth_transport: Any | None = None, graph_transport: Any | None = None
) -> Any:
    """Build the FastAPI app for this launch plan.

    `oauth_transport` and `graph_transport` are httpx mock seams used by the
    acceptance tests. They default to None (production path).

    All dependency-sensitive imports (fastapi, oauth_mod, app_only,
    graph.actions, health) happen here, AFTER `plan_launch()` has confirmed
    the dependency probe is clean. Importing the launcher module itself
    must remain safe when these third-party packages are absent.
    """
    from fastapi import FastAPI

    from .auth import oauth as oauth_mod
    from .auth.app_only import CertificateMaterial, acquire_with_certificate, acquire_with_secret
    from .graph.actions import invoke as invoke_action
    from .graph.actions import list_actions
    from .health import compose_readiness

    app = FastAPI(title=f"SMARTHAUS M365 Runtime {RUNTIME_VERSION}")

    token_store = _make_token_store(plan)
    # plan:m365-cps-trkB-p6-auth-mode-tiers:T3 / L113.L_TOKEN_STORE_PERSISTS_TIER
    # Restore session tier from token store on rebuild; default read-only.
    persisted_tier: str | None = None
    if token_store is not None:
        try:
            persisted_tier = token_store.get(TOKEN_ACCOUNT_SESSION_TIER)
        except Exception:
            persisted_tier = None
    from .graph.registry import ALLOWED_TIERS as _ALLOWED_TIERS  # noqa: WPS433

    initial_tier = (
        persisted_tier if persisted_tier in _ALLOWED_TIERS else DEFAULT_SESSION_TIER
    )

    state: dict[str, Any] = {
        "access_token": None,
        "refresh_token": None,
        "token_expires_at": None,
        "auth_mode": plan.setup.auth_mode if plan.setup else None,
        "device_code_session": None,
        "pkce_session": None,
        "auth_failure": None,
        "session_tier": initial_tier,
    }

    def current_setup() -> SetupConfig | None:
        return plan.setup

    def _scopes_for_refresh(setup: SetupConfig) -> list[str]:
        return list(setup.granted_scopes) or ["https://graph.microsoft.com/.default"]

    def _clear_in_memory_access(reason: str) -> None:
        state["access_token"] = None
        state["token_expires_at"] = None
        state["auth_failure"] = reason

    def _refresh_from_stored_token(reason: str) -> bool:
        setup = current_setup()
        if not _delegated_refresh_supported(setup):
            return False
        assert setup is not None
        refresh_token = state.get("refresh_token") or _store_get(token_store, TOKEN_ACCOUNT_REFRESH)
        if not refresh_token:
            _clear_in_memory_access(f"{reason}:refresh_token_missing")
            return False
        state["refresh_token"] = refresh_token
        try:
            token = oauth_mod.refresh_access_token(
                setup.tenant_id,
                setup.client_id,
                refresh_token,
                _scopes_for_refresh(setup),
                transport=oauth_transport,
            )
        except oauth_mod.OAuthError as exc:
            _clear_in_memory_access(exc.code)
            return False
        _ingest_token_response(state, token_store, token)
        return bool(state.get("access_token"))

    def _hydrate_auth_state_from_store() -> None:
        setup = current_setup()
        if setup is None or token_store is None:
            return
        stored_access = _store_get(token_store, TOKEN_ACCOUNT_ACCESS)
        stored_refresh = _store_get(token_store, TOKEN_ACCOUNT_REFRESH)
        stored_expires_at = _coerce_expires_at(_store_get(token_store, TOKEN_ACCOUNT_EXPIRES_AT))
        if stored_refresh:
            state["refresh_token"] = stored_refresh
        if stored_access and _token_is_fresh(stored_expires_at):
            state["access_token"] = stored_access
            state["token_expires_at"] = stored_expires_at
            state["auth_failure"] = None
            return
        if stored_refresh and _delegated_refresh_supported(setup):
            _refresh_from_stored_token("startup_refresh")
            return
        if stored_access:
            _clear_in_memory_access("stored_access_token_unusable")

    def _ensure_access_token_current() -> bool:
        access_token = state.get("access_token")
        expires_at = _coerce_expires_at(state.get("token_expires_at"))
        if access_token and _token_is_fresh(expires_at):
            return True
        if _delegated_refresh_supported(current_setup()):
            return _refresh_from_stored_token("lazy_refresh")
        if access_token:
            _clear_in_memory_access("access_token_expired")
        return False

    _hydrate_auth_state_from_store()

    def emit_audit(
        actor: str, action: str, status: str, *, extra: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        return build_envelope(
            actor=actor,
            action=action,
            status_class=status,
            extra=extra or {},
            correlation_id=str(uuid.uuid4()),
        )

    @app.get("/v1/runtime/version")
    def version() -> dict[str, Any]:
        return {
            "runtime_version": RUNTIME_VERSION,
            "installed_root": str(plan.installed_root),
            "outcome": plan.outcome,
            "auth_mode": state["auth_mode"],
            "token_store_backend": token_store.backend if token_store else None,
        }

    @app.get("/v1/health/dependencies")
    def dependencies_endpoint() -> dict[str, Any]:
        auth_mode = plan.setup.auth_mode if plan.setup else None
        present, missing = _probe_required_dependencies(auth_mode=auth_mode)
        envelope = emit_audit(
            "system",
            "health.dependencies",
            "success" if not missing else "dependency_missing",
            extra={"present": present, "missing": missing, "auth_mode": auth_mode},
        )
        return {
            "required_modules": list(RUNTIME_REQUIRED_MODULES),
            "conditional_modules": {k: list(v) for k, v in RUNTIME_CONDITIONAL_MODULES.items()},
            "auth_mode": auth_mode,
            "present_modules": present,
            "missing_modules": missing,
            "audit": envelope,
        }

    @app.get("/v1/health/readiness")
    def readiness_endpoint() -> dict[str, Any]:
        _ensure_access_token_current()
        result = compose_readiness(
            plan.installed_root,
            plan.setup,
            token_store,
            state.get("access_token"),
            transport=graph_transport,
        )
        envelope = emit_audit(
            "system", "health.readiness", result.detail["state"], extra=result.detail
        )
        return {"vector": result.vector.as_dict(), "state": result.detail, "audit": envelope}

    @app.get("/v1/auth/status")
    def auth_status() -> dict[str, Any]:
        _ensure_access_token_current()
        if state.get("access_token") and _token_is_fresh(
            _coerce_expires_at(state.get("token_expires_at"))
        ):
            return {"state": "signed_in", "auth_mode": state["auth_mode"]}
        if plan.setup is None:
            return {"state": "unconfigured"}
        if state.get("device_code_session"):
            return {"state": "consent_required", "auth_mode": state["auth_mode"]}
        if state.get("auth_failure"):
            return {
                "state": "auth_required",
                "auth_mode": state["auth_mode"],
                "reason": state["auth_failure"],
            }
        return {"state": "auth_required", "auth_mode": state["auth_mode"]}

    @app.post("/v1/auth/clear")
    def auth_clear() -> dict[str, Any]:
        state["access_token"] = None
        state["refresh_token"] = None
        state["token_expires_at"] = None
        state["device_code_session"] = None
        state["pkce_session"] = None
        state["auth_failure"] = None
        _clear_stored_tokens(token_store)
        return {"state": "auth_required"}

    @app.post("/v1/auth/start")
    def auth_start(body: dict[str, Any] | None = None) -> dict[str, Any]:
        body = body or {}
        # plan:m365-cps-trkB-p6-auth-mode-tiers:T2 / L113.L_TIER_VALIDATED
        # Validate tier BEFORE the setup check so bad input fails fast.
        requested_tier = body.get("tier")
        if requested_tier is not None and requested_tier not in _ALLOWED_TIERS:
            return {
                "state": "config_invalid",
                "reason": "invalid_tier",
                "allowed_tiers": sorted(_ALLOWED_TIERS),
                "audit": emit_audit(
                    str(body.get("actor") or "system"),
                    "auth.start",
                    "config_invalid",
                    extra={"reason": "invalid_tier", "tier": requested_tier},
                ),
            }
        setup = current_setup()
        if setup is None:
            return {
                "state": "unconfigured",
                "audit": emit_audit("system", "auth.start", "not_configured"),
            }
        # L113.L_AUTH_START_ACCEPTS_TIER — record validated tier in state + token store
        if requested_tier is not None:
            state["session_tier"] = requested_tier
            if token_store is not None:
                try:
                    token_store.put(TOKEN_ACCOUNT_SESSION_TIER, requested_tier)
                except Exception:
                    # Persistence failure is non-fatal; in-memory tier still applies.
                    pass
        scopes = list(setup.granted_scopes) or ["https://graph.microsoft.com/.default"]
        actor = str(body.get("actor") or setup.actor_upn)
        if setup.auth_mode == "auth_code_pkce":
            if not setup.redirect_uri:
                return {
                    "state": "config_invalid",
                    "reason": "redirect_uri_missing",
                    "audit": emit_audit(actor, "auth.start", "not_configured"),
                }
            pkce = oauth_mod.make_pkce()
            url = oauth_mod.authorize_url(
                setup.tenant_id, setup.client_id, setup.redirect_uri, scopes, pkce
            )
            state["pkce_session"] = {
                "verifier": pkce.code_verifier,
                "state": pkce.state,
                "scopes": scopes,
            }
            state["device_code_session"] = None
            state["auth_failure"] = None
            return {
                "state": "auth_started",
                "auth_mode": "auth_code_pkce",
                "authorize_url": url,
                "expected_state": pkce.state,
                "audit": emit_audit(
                    actor, "auth.start", "auth_started", extra={"flow": "auth_code_pkce"}
                ),
            }
        if setup.auth_mode == "device_code":
            try:
                resp = oauth_mod.request_device_code(
                    setup.tenant_id, setup.client_id, scopes, transport=oauth_transport
                )
            except oauth_mod.OAuthError as exc:
                state["auth_failure"] = exc.code
                return {
                    "state": "auth_required",
                    "reason": exc.code,
                    "audit": emit_audit(
                        actor, "auth.start", "auth_required", extra={"reason": exc.code}
                    ),
                }
            state["device_code_session"] = {
                "device_code": resp["device_code"],
                "user_code": resp["user_code"],
                "verification_uri": resp["verification_uri"],
                "interval": resp.get("interval", 5),
                "expires_in": resp.get("expires_in", 900),
                "scopes": scopes,
            }
            state["pkce_session"] = None
            state["auth_failure"] = None
            return {
                "state": "device_code_pending",
                "auth_mode": "device_code",
                "user_code": resp["user_code"],
                "verification_uri": resp["verification_uri"],
                "interval": resp.get("interval", 5),
                "audit": emit_audit(
                    actor, "auth.start", "consent_required", extra={"flow": "device_code"}
                ),
            }
        if setup.auth_mode == "app_only_secret":
            secret = _looked_up_secret_or_cert_ref(setup, token_store, "secret")
            if not secret:
                return {
                    "state": "config_invalid",
                    "reason": "client_secret_unresolved",
                    "audit": emit_audit(actor, "auth.start", "not_configured"),
                }
            try:
                token = acquire_with_secret(
                    setup.tenant_id, setup.client_id, secret, scopes, transport=oauth_transport
                )
            except oauth_mod.OAuthError as exc:
                state["auth_failure"] = exc.code
                return {
                    "state": "auth_required",
                    "reason": exc.code,
                    "audit": emit_audit(
                        actor, "auth.start", "auth_required", extra={"reason": exc.code}
                    ),
                }
            _ingest_token_response(state, token_store, token)
            return {
                "state": "signed_in",
                "auth_mode": "app_only_secret",
                "audit": emit_audit(
                    actor, "auth.start", "success", extra={"flow": "app_only_secret"}
                ),
            }
        if setup.auth_mode == "app_only_certificate":
            pem = _looked_up_secret_or_cert_ref(setup, token_store, "certificate")
            thumbprint = ""
            if token_store is not None and setup.app_only_certificate_ref:
                try:
                    thumbprint = (
                        token_store.get(f"{setup.app_only_certificate_ref}::thumbprint") or ""
                    ).strip()
                except Exception:
                    thumbprint = ""
            if not pem or not thumbprint:
                return {
                    "state": "config_invalid",
                    "reason": "certificate_material_unresolved",
                    "audit": emit_audit(actor, "auth.start", "not_configured"),
                }
            cert = CertificateMaterial(pem_private_key=pem, thumbprint_sha1_hex=thumbprint)
            try:
                token = acquire_with_certificate(
                    setup.tenant_id, setup.client_id, cert, scopes, transport=oauth_transport
                )
            except oauth_mod.OAuthError as exc:
                state["auth_failure"] = exc.code
                return {
                    "state": "auth_required",
                    "reason": exc.code,
                    "audit": emit_audit(
                        actor, "auth.start", "auth_required", extra={"reason": exc.code}
                    ),
                }
            _ingest_token_response(state, token_store, token)
            return {
                "state": "signed_in",
                "auth_mode": "app_only_certificate",
                "audit": emit_audit(
                    actor, "auth.start", "success", extra={"flow": "app_only_certificate"}
                ),
            }
        return {"state": "auth_required", "reason": "auth_mode_unsupported"}

    @app.post("/v1/auth/check")
    def auth_check(body: dict[str, Any] | None = None) -> dict[str, Any]:
        body = body or {}
        setup = current_setup()
        if setup is None:
            return {
                "state": "unconfigured",
                "audit": emit_audit("system", "auth.check", "not_configured"),
            }
        actor = str(body.get("actor") or setup.actor_upn)
        if setup.auth_mode == "auth_code_pkce":
            session = state.get("pkce_session")
            if session is None:
                return {
                    "state": "auth_required",
                    "reason": "no_pkce_session",
                    "audit": emit_audit(actor, "auth.check", "auth_required"),
                }
            received_state = str(body.get("state") or "")
            code = str(body.get("code") or "")
            if not code or received_state != session["state"]:
                state["auth_failure"] = "pkce_state_mismatch"
                return {
                    "state": "auth_required",
                    "reason": "pkce_state_mismatch",
                    "audit": emit_audit(actor, "auth.check", "auth_required"),
                }
            try:
                token = oauth_mod.exchange_authorization_code(
                    setup.tenant_id,
                    setup.client_id,
                    code,
                    setup.redirect_uri or "",
                    session["verifier"],
                    session["scopes"],
                    transport=oauth_transport,
                )
            except oauth_mod.OAuthError as exc:
                state["auth_failure"] = exc.code
                return {
                    "state": "auth_required",
                    "reason": exc.code,
                    "audit": emit_audit(
                        actor, "auth.check", "auth_required", extra={"reason": exc.code}
                    ),
                }
            _ingest_token_response(state, token_store, token)
            state["pkce_session"] = None
            return {
                "state": "signed_in",
                "auth_mode": "auth_code_pkce",
                "audit": emit_audit(actor, "auth.check", "success"),
            }
        if setup.auth_mode == "device_code":
            session = state.get("device_code_session")
            if session is None:
                return {
                    "state": "auth_required",
                    "reason": "no_device_code_session",
                    "audit": emit_audit(actor, "auth.check", "auth_required"),
                }
            try:
                token = oauth_mod.poll_device_code(
                    setup.tenant_id,
                    setup.client_id,
                    session["device_code"],
                    transport=oauth_transport,
                )
            except oauth_mod.OAuthError as exc:
                state["auth_failure"] = exc.code
                return {
                    "state": "auth_required",
                    "reason": exc.code,
                    "audit": emit_audit(
                        actor, "auth.check", "auth_required", extra={"reason": exc.code}
                    ),
                }
            if token.get("pending"):
                return {
                    "state": "device_code_pending",
                    "auth_mode": "device_code",
                    "audit": emit_audit(actor, "auth.check", "consent_required"),
                }
            _ingest_token_response(state, token_store, token)
            state["device_code_session"] = None
            return {
                "state": "signed_in",
                "auth_mode": "device_code",
                "audit": emit_audit(actor, "auth.check", "success"),
            }
        # App-only modes complete on auth.start, so check just reports current state.
        return {
            "state": "signed_in" if state.get("access_token") else "auth_required",
            "auth_mode": setup.auth_mode,
        }

    @app.get("/v1/actions")
    def actions() -> dict[str, Any]:
        return {"count": len(READ_ONLY_REGISTRY), "actions": list_actions()}

    @app.post("/v1/auth/preflight")
    def auth_preflight(body: dict[str, Any] | None = None) -> dict[str, Any]:
        # plan:m365-cps-trkA-p3-preflight-intersection:T3 / L102
        # Pure read; returns the registry partition for this session.
        from .graph.preflight import compute_intersection

        body = body or {}
        # Derive auth_mode from body, else from current session, else None.
        auth_mode = body.get("auth_mode")
        if not auth_mode:
            setup = current_setup()
            auth_mode = setup.auth_mode if setup is not None else None
        # Derive granted_scopes similarly.
        scopes = body.get("granted_scopes")
        if not scopes:
            setup = current_setup()
            scopes = list(setup.granted_scopes) if setup is not None else []
        return compute_intersection(auth_mode, scopes)

    @app.get("/v1/inventory")
    def inventory_endpoint() -> dict[str, Any]:
        # plan:m365-cps-trkA-p2-inventory-tool:T2 / L101.InventoryContractValid
        # Surfaces what the runtime actually implements vs what agents.yaml advertises.
        # GET-only; no body, no auth, no Graph call.
        try:
            from ucp_m365_pack.client import LEGACY_ACTION_TO_RUNTIME_ACTION
        except Exception:
            LEGACY_ACTION_TO_RUNTIME_ACTION = {}

        agents_data: dict[str, Any] = {}
        try:
            import yaml as _yaml

            registry_yaml_path = (
                Path(__file__).resolve().parent.parent.parent / "registry" / "agents.yaml"
            )
            if registry_yaml_path.is_file():
                agents_data = _yaml.safe_load(registry_yaml_path.read_text()) or {}
        except Exception:
            agents_data = {}

        advertised: set[str] = set()
        agent_summary: dict[str, dict[str, int]] = {}
        impl_keys = set(READ_ONLY_REGISTRY.keys())
        alias_keys = set(LEGACY_ACTION_TO_RUNTIME_ACTION.keys())
        for agent_id, agent_cfg in (agents_data.get("agents") or {}).items():
            if not isinstance(agent_cfg, dict):
                continue
            allowed = agent_cfg.get("allowed_actions") or []
            agent_advertised: set[str] = set()
            for entry in allowed:
                if isinstance(entry, str):
                    agent_advertised.add(entry)
            advertised |= agent_advertised
            implemented = sum(1 for a in agent_advertised if a in impl_keys)
            aliased = sum(1 for a in agent_advertised if a in alias_keys)
            planned = len(agent_advertised) - implemented - aliased
            agent_summary[agent_id] = {
                "total": len(agent_advertised),
                "implemented": implemented,
                "aliased": aliased,
                "planned": max(planned, 0),
            }

        advertised_only = sorted(advertised - alias_keys - impl_keys)

        return {
            "implemented_actions": list_actions(),
            "alias_map": dict(LEGACY_ACTION_TO_RUNTIME_ACTION),
            "advertised_only": advertised_only,
            "agent_summary": agent_summary,
            "runtime_version": RUNTIME_VERSION,
        }

    @app.post("/v1/actions/{action_id}/invoke")
    def invoke_endpoint(action_id: str, body: dict[str, Any] | None = None) -> dict[str, Any]:
        body = body or {}
        actor = str(body.get("actor") or (plan.setup.actor_upn if plan.setup else "unknown"))
        params = dict(body.get("params") or {})
        if action_id not in READ_ONLY_REGISTRY:
            # plan:m365-cps-trkA-p1-status-code-semantics:T2 / L100.L_FIX_UNKNOWN_ACTION
            # Unknown actions surface distinctly from mutation_fence so callers can
            # diagnose "I don't know that action" vs "I refused to write".
            return {
                "status_class": "unknown_action",
                "reason": "action_not_in_read_only_registry",
                "audit": build_envelope(
                    actor=actor,
                    action=action_id,
                    status_class="unknown_action",
                    extra={"params": params},
                ),
            }
        if plan.setup is None:
            return {
                "status_class": "not_configured",
                "audit": build_envelope(
                    actor=actor,
                    action=action_id,
                    status_class="not_configured",
                    extra={"params": params},
                ),
            }
        # plan:m365-cps-trkB-p6-auth-mode-tiers:T2 / L113.L_INVOKE_FORWARDS_TIER
        result = invoke_action(
            action_id=action_id,
            actor=actor,
            granted_scopes=plan.setup.granted_scopes,
            current_auth_mode=plan.setup.auth_mode,
            access_token=state.get("access_token") if _ensure_access_token_current() else None,
            params=params,
            transport=graph_transport,
            current_tier=state.get("session_tier", DEFAULT_SESSION_TIER),
        )
        return {
            "status_class": result.status_class,
            "payload": result.payload,
            "audit": result.audit,
            "correlation_id": result.correlation_id,
        }

    return app


def _ingest_token_response(
    state: dict[str, Any], token_store: TokenStore | None, token: dict[str, Any]
) -> None:
    state["access_token"] = token.get("access_token")
    state["refresh_token"] = token.get("refresh_token") or state.get("refresh_token")
    state["token_expires_at"] = token.get("expires_at") or 0
    state["auth_failure"] = None
    _store_access_token(
        token_store,
        state["access_token"],
        state.get("refresh_token"),
        _coerce_expires_at(state.get("token_expires_at")),
    )


def run(host: str = "127.0.0.1", port: int = 9300) -> int:
    plan = plan_launch(host=host, port=port)
    if plan.outcome != "started":
        sys.stderr.write(f"M365 runtime launch failed: {plan.outcome} {plan.detail}\n")
        return 1
    try:
        import uvicorn
    except ImportError:
        sys.stderr.write("uvicorn missing; cannot run server\n")
        return 1
    app = build_app(plan)
    uvicorn.run(
        app,
        host=plan.listen_host,
        port=plan.listen_port,
        log_level=os.getenv("M365_RUNTIME_LOG_LEVEL", "info").lower(),
    )
    return 0
